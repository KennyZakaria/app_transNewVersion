<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('devis', function (Blueprint $table) {
            $table->string('typeVehicule')->nullable();  
            $table->date('dateDebut')->nullable();  
            $table->date('dateFin')->nullable();  
            $table->text('description')->nullable();  
            $table->boolean('flexibleDate')->nullable();   
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('devis', function (Blueprint $table) {
            $table->dropColumn([
                'typeVehicule',
                'dateDebut',
                'dateFin',
                'description',
                'flexibleDate', 
            ]);
        });
    }
};

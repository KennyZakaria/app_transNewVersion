<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('offres.index')); ?>" method="GET" id="searchForm">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-2 main-dashboard-item">
                <label for="dateDebut">Date Début :</label>
                <input type="date" class="form-control" name="dateDebut" placeholder="Entrez la date de début"
                    value="<?php echo e(request('dateDebut')); ?>">
            </div>

            <div class="col-md-2 main-dashboard-item">
                <label for="dateFin">Date Fin :</label>
                <input type="date" class="form-control" name="dateFin" placeholder="Entrez la date de fin"
                    value="<?php echo e(request('dateFin')); ?>">
            </div>

            <div class="col-md-2 main-dashboard-item">
                <label for="placeDepart">Lieu de Départ :</label>
                <input type="text" class="form-control" name="placeDepart" placeholder="Entrez le lieu de départ"
                    value="<?php echo e(request('placeDepart')); ?>">
            </div>

            <div class="col-md-2 main-dashboard-item">
                <label for="placeArrivee">Lieu d'Arrivée :</label>
                <input type="text" class="form-control" name="placeArrivee" placeholder="Entrez le lieu d'arrivée"
                    value="<?php echo e(request('placeArrivee')); ?>">
            </div>
            <div class="col-md-4 main-dashboard-item">
                <label for="categorie">Catégorie :</label>
                <select class="form-control" name="categorie" id="categorie">
                    <option value="" <?php echo e(!request('categorie') ? 'selected' : ''); ?>>Sélectionnez une catégorie</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('categorie') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->nomFr); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>
        <div class="row justify-content-end py-3">
            <div class="col-md-5 col-12 btn-pq">
                <button class="btn btn-primary a3 reset" id="resetButton" type="button">Annuler</button>
                <button class="btn btn-primary a3" id="submitButton" type="submit">Rechercher</button>
            </div>
        </div>
    </form>
    <div class="table-responsive demand">
        <table class="table">
            <thead>
                <tr>
                    <th><span>Catégorie</span></th>
                    <th><span>Availablity</span></th>
                    <th><span>Status</span></th>
                    <th><span>Nombre Devis</span></th>
                    <th><span>Route</span></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $offres['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($offre['categorie']['nomFr']); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($offre['dateDebut'])->format('d/m/Y')); ?> -
                            <?php echo e(\Carbon\Carbon::parse($offre['dateFin'])->format('d/m/Y')); ?></td>
                        <td>
                            <span
                                class="badge
                                <?php if($offre['status'] === 'Valide'): ?> text-bg-success
                                <?php elseif($offre['status'] === 'EnAttenteDeValidation'): ?>
                                    text-bg-warning
                                <?php elseif($offre['status'] === 'Rejete'): ?>
                                    text-bg-danger
                                <?php elseif($offre['status'] === 'Termine'): ?>
                                    text-bg-info <?php endif; ?>">
                                <?php echo e($offre['status']); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('liste.devis.by.deamnde', ['IdDemande' => $offre['id']])); ?>">
                                <?php echo e($offre['devis_count']); ?>

                            </a>


                        </td>
                        <td class="td_table">
                            <div>
                                <span>
                                    <?php echo e(Illuminate\Support\Str::limit($offre['place_depart']['nomFr'], 8, '')); ?>

                                    <img src="../assets/img/transexpress.ma.png">
                                    <?php echo e(Illuminate\Support\Str::limit($offre['place_arrivee']['nomFr'], 8, '')); ?>

                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn-action btn-secondary" type="button" id="dropdownAction"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    ...
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownAction">
                                    <li class="nav-item dropdown">
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('change.status.offre', ['id' => $offre['id'], 'status' => 'Valide'])); ?>">
                                            Valide
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('change.status.offre', ['id' => $offre['id'], 'status' => 'Rejete'])); ?>">
                                            Rejeté
                                        </a>
                                    </li>
                                    <li class="separate"></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var searchForm = document.getElementById('searchForm');
            var resetButton = document.getElementById('resetButton');
            resetButton.addEventListener('click', function() {
                document.getElementsByName('dateDebut')[0].value = '';
                document.getElementsByName('dateFin')[0].value = '';

                // Reset text inputs
                document.getElementsByName('placeDepart')[0].value = '';
                document.getElementsByName('placeArrivee')[0].value = '';

                // Reset select dropdown
                var categorieDropdown = document.getElementById('categorie');
                categorieDropdown.selectedIndex = 0;
                searchForm.submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kenny\Desktop\app_transNewVersion\resources\views\offres\index.blade.php ENDPATH**/ ?>
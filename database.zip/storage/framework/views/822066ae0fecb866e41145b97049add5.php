<?php $__env->startSection('content'); ?>
    <h2 class="titre-accepted-offres">Liste <span>Devis</span></h2>

    <div class="table-responsive demand">
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Prix</th>
                    <th>Status</th>
                    <th>Description</th>
                    <th>Flexible Date</th>
                    <th>Message</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $devis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($devi->date); ?></td>
                        <td><?php echo e($devi->prix); ?></td>
                        <td>
                            <span
                            class="badge
                            <?php if($devi->status === 'Accepte'): ?> text-bg-success
                            <?php elseif($devi->status=== 'EnCours'): ?>
                                text-bg-warning
                            <?php elseif($devi->status === 'Annule'): ?>
                                text-bg-danger <?php endif; ?>">
                            <?php echo e($devi->status); ?>

                        </span>
                        </td>
                        <td><?php echo e($devi->description); ?></td>
                        <td><?php echo e($devi->flexibleDate ? 'Oui' : 'Non'); ?></td>

                        <td>
                            <a href="<?php echo e(route('liste.chat', ['deviId' => $devi->id])); ?>">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">Aucun devis trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var searchForm = document.getElementById('searchForm');
            var resetButton = document.getElementById('resetButton');
            resetButton.addEventListener('click', function() {
                document.getElementsByName('dateDebut')[0].value = '';
                document.getElementsByName('dateFin')[0].value = '';

                // Reset text inputs
                document.getElementsByName('placeDepart')[0].value = '';
                document.getElementsByName('placeArrivee')[0].value = '';

                // Reset select dropdown
                var categorieDropdown = document.getElementById('categorie');
                categorieDropdown.selectedIndex = 0;
                searchForm.submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kenny\Desktop\app_transNewVersion\resources\views\offres\listeDevis.blade.php ENDPATH**/ ?>
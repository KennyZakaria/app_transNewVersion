<?php $__env->startSection('content'); ?>
    <h2 class="titre-accepted-offres">Details <span>Transporteur</span></h2>
    <form class="pg-contact">
        <div class="row justify-content-center profile">
            <div class="col-md-5">
                <div>
                    <label>Name</label>
                    <input type="text" class="form-control" readonly value="<?php echo e($transporteur->user->lastName); ?>">
                </div>
                <div>
                    <label>Phone</label>
                    <input type="text" class="form-control" readonly value="<?php echo e($transporteur->user->tel); ?>">
                </div>

            </div>
            <div class="col-md-5">
                <div>
                    <label>First name</label>
                    <input type="text" class="form-control" readonly value="<?php echo e($transporteur->user->firstName); ?>">
                </div>
                <div>
                    <label>Email</label>
                    <input type="email" class="form-control" readonly value="<?php echo e($transporteur->user->email); ?>">
                </div>

            </div>


        </div>
        <div class="row justify-content-center profile">
            <div class="col-md-5">
                <div>
                    <label>Type</label>
                    <input type="text" class="form-control" readonly value="<?php echo e($transporteur->status); ?>">
                </div>
                <div>
                        <label>Cine</label>
                        <img  width="100px" src="<?php echo e($transporteur->CinRectoURU); ?>" />
                        <img   width="100px" src="<?php echo e($transporteur->CinVersoURU); ?>" />



                </div>

            </div>
            <div class="col-md-5">
                <div>
                    <label>Ville</label>
                    <input type="text" class="form-control" readonly value="<?php echo e($transporteur->ville->villeNameFr); ?>">
                </div>
                <div>
                    <label>Véhicule</label>
                    <img width="100px" src="<?php echo e($transporteur->VehicleURUS); ?>" />
                </div>

            </div>


        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kenny\Desktop\app_transNewVersion\resources\views\transporteurs\detail.blade.php ENDPATH**/ ?>